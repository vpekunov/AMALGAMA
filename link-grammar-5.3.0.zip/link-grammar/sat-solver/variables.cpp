#include "variables.hpp"

#ifdef _VARS
ostream& var_defs_stream = cerr;
#endif
